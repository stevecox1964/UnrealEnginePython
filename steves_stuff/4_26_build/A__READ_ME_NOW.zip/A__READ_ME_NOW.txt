These are pre-compiled 4.26 versions of the UnrealEnginePython binaries.

You will need to install these binaries as well as the Python 3.X binaries in same dir

To install:
1. Create a "Plugins" directory in your Unreal 4.26 project you want to use Python in
2. git clone https://github.com/stevecox1964/UnrealEnginePython into this "Plugins" directory
3. So right now you should have "Plugins\UnrealEnginePython" with UnrealEnginePython master content inside
4. Create a (where ever you Unreal project lives)\Plugins\UnrealEnginePython\Binaries\Win64 directory
5. Copy the files from UnrealEnginePython\steves_stuff\4.26 Build\ git hub project into the Win64 dir
6. Go download a windows version of Python runtime and extract into same Win64 dir
7. Files in Win64 should look like this below
8. Go watch my video ;) https://www.youtube.com/watch?v=PBq6eDdaaqI&t=2s

 get-pip.py
 InstallPip.bat
 pyexpat.pyd
 python.exe
 python3.dll
 python36.dll
 pythonw.exe
 select.pyd
 sqlite3.dll
 UE4Editor-PythonAutomation.dll
 UE4Editor-PythonAutomation.pdb
 UE4Editor-PythonConsole.dll
 UE4Editor-PythonConsole.pdb
 UE4Editor-PythonEditor.dll
 UE4Editor-PythonEditor.pdb
 UE4Editor-UnrealEnginePython.dll
 UE4Editor-UnrealEnginePython.pdb
 UE4Editor.modules
 unicodedata.pyd
 vcruntime140.dll
 winsound.pyd
 _asyncio.pyd
 _bz2.pyd
 _ctypes.pyd
 _decimal.pyd
 _elementtree.pyd
 _hashlib.pyd
 _lzma.pyd
 _msi.pyd
 _multiprocessing.pyd
 _overlapped.pyd
 _socket.pyd
 _sqlite3.pyd
 _ssl.pyd




